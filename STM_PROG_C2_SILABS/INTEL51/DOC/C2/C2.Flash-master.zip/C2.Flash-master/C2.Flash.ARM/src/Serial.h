#ifndef __SERIAL_H__
#define __SERIAL_H__

#include "stdint.h"

uint16_t atox (char * s);
uint32_t atolx (char * s);

#endif // __SERIAL_H__
